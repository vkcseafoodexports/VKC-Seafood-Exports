VKC SEAFOOD EXPORTS — COMPLETE FREE WEBSITE
==============================================

Included:
- Premium responsive homepage
- About VKC
- White Squid (Loligo)
- Cuttlefish
- Ribbon Fish
- Other Seafood
- Quality & Processing workflow
- Export & Logistics workflow
- Global markets
- Buyer types
- Request-a-Quote form
- Email + WhatsApp contact
- Mobile navigation
- No paid website builder required

Important:
- The visual photos are crops from the design reference supplied in the conversation. Replace them with your actual company/product/plant photos before public launch.
- The website deliberately avoids unverified claims such as HACCP/ISO/FDA/EU certification.
- Verify your company email, phone, registration details, processing facility details, certifications and product specifications before publishing.

FREE PUBLISHING — GITHUB PAGES
1. Create a free GitHub account.
2. Create a PUBLIC repository named e.g. vkc-seafood-exports.
3. Upload index.html, styles.css, script.js and the assets folder.
4. Repository Settings → Pages.
5. Source: Deploy from a branch → main → /(root) → Save.
6. GitHub will provide a free URL.

CUSTOM DOMAIN LATER
You can later connect a domain such as vkcseafoodexports.com without changing the website files.

CONTACT DETAILS CURRENTLY USED
VKC Seafood Exports
Kerala, India
Email: vkcseafoodexports@gmail.com
Phone/WhatsApp: +91 96332 52567
