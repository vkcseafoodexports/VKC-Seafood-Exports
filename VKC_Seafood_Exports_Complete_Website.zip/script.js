const nav=document.getElementById('nav');
document.querySelector('.hamburger').addEventListener('click',()=>nav.classList.toggle('open'));
document.querySelectorAll('#nav a').forEach(a=>a.addEventListener('click',()=>nav.classList.remove('open')));

const productButtons=document.querySelectorAll('.link-btn');
productButtons.forEach(btn=>btn.addEventListener('click',()=>{
  document.querySelector('#quote').scrollIntoView({behavior:'smooth'});
  setTimeout(()=>document.querySelector('select[name="product"]').value=btn.dataset.product,350);
  const toast=document.getElementById('toast'); toast.classList.add('show'); setTimeout(()=>toast.classList.remove('show'),2200);
}));

document.getElementById('quoteForm').addEventListener('submit',e=>{
  e.preventDefault();
  const d=Object.fromEntries(new FormData(e.target).entries());
  const subject=encodeURIComponent(`Seafood Export Enquiry - ${d.product}`);
  const body=encodeURIComponent(
`Name: ${d.name}
Company: ${d.company}
Email: ${d.email}
Phone/WhatsApp: ${d.phone}
Product: ${d.product}
Quantity: ${d.quantity}
Size/Grade: ${d.size}
Destination Port: ${d.destination}
Commercial Basis: ${d.terms}

Requirements:
${d.message}`
  );
  location.href=`mailto:vkcseafoodexports@gmail.com?subject=${subject}&body=${body}`;
});
